package mx.unam.ciencias.modelado.practica1.personajes;

/**Enumeración de las franquicias de los personajes */
public enum Franquicia{
    Nientiendo,
    Copcam,
    Chinpokomon;
}